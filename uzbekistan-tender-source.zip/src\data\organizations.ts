export const MOCK_ORGANIZATIONS = [
  {
    id: "ORG-101",
    name: "Bino Qurilish Servis MChJ",
    inn: "***-**-1234",
    director: "Abdullayev B. A.",
    founded: "2015-06-12",
    region: "Tashkent",
    address: "Toshkent sh., Yunusobod tumani, 12-mavze, 45-uy",
    status: "active",
    riskScore: 82,
    history: {
      totalTenders: 15,
      wonTenders: 4,
      totalAmount: 12500000000,
      cancelledContracts: 1,
      delayedContracts: 2
    },
    signals: [
      { type: "conflict", description: "Manfaatlar to'qnashuvi ehtimoli (rahbarlar bir xil manzilda ro'yxatdan o'tgan)", date: "2025-02-10", source: "Soliq qo'mitasi (Demo)" },
      { type: "experience", description: "Shu hajmrdagi loyihalar tajribasi yetarli emas", date: "2025-02-12", source: "Tender portali" }
    ]
  },
  {
    id: "ORG-102",
    name: "Qurilish Standart Plus",
    inn: "***-**-5678",
    director: "Karimov S. T.",
    founded: "2010-03-20",
    region: "Tashkent",
    address: "Toshkent sh., Chilonzor tumani, 5-mavze, 12-uy",
    status: "active",
    riskScore: 25,
    history: {
      totalTenders: 42,
      wonTenders: 18,
      totalAmount: 85000000000,
      cancelledContracts: 0,
      delayedContracts: 1
    },
    signals: []
  },
  {
    id: "ORG-401",
    name: "Energo Qurilish Invest",
    inn: "***-**-1111",
    director: "Rahimov D. E.",
    founded: "2018-11-05",
    region: "Bukhara",
    address: "Buxoro sh., Islom Karimov ko'chasi, 23-uy",
    status: "active",
    riskScore: 70,
    history: {
      totalTenders: 8,
      wonTenders: 3,
      totalAmount: 45000000000,
      cancelledContracts: 2,
      delayedContracts: 3
    },
    signals: [
      { type: "history", description: "Oldingi 2 ta shartnoma bekor qilingan", date: "2024-11-15", source: "Davlat xaridlari portali" },
      { type: "tax", description: "Soliq qarzdorligi xavfi signali", date: "2025-01-20", source: "Soliq qo'mitasi (Demo)" }
    ]
  }
];
