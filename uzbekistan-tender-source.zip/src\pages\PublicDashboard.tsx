import { useTranslation } from "react-i18next";
import { DemoBadge } from "@/components/DemoBadge";
import { MOCK_DASHBOARD } from "@/data/dashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from "recharts";

export default function PublicDashboard() {
  const { t } = useTranslation();

  const pieData = [
    { name: "Green", value: MOCK_DASHBOARD.greenRisks, color: "hsl(var(--risk-green))" },
    { name: "Yellow", value: MOCK_DASHBOARD.yellowRisks, color: "hsl(var(--risk-yellow))" },
    { name: "Red", value: MOCK_DASHBOARD.redRisks, color: "hsl(var(--risk-red))" }
  ];

  return (
    <div className="container mx-auto px-4 py-12 space-y-8">
      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.public_dashboard")} <DemoBadge />
        </h1>
        <p className="text-lg text-muted-foreground max-w-3xl">
          {t("intro.public_dashboard")}
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Jami tenderlar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{MOCK_DASHBOARD.totalTenders.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Qizil risklar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-risk-red">{MOCK_DASHBOARD.redRisks.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Sariq risklar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-risk-yellow">{MOCK_DASHBOARD.yellowRisks.toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Narx farqi yuqori</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{MOCK_DASHBOARD.highPriceDeviation.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Risk statuslari ulushi</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px] flex justify-center items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2} dataKey="value">
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sohalar kesimida risklar</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MOCK_DASHBOARD.riskBySector}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip />
                <Bar dataKey="red" stackId="a" fill="hsl(var(--risk-red))" />
                <Bar dataKey="yellow" stackId="a" fill="hsl(var(--risk-yellow))" />
                <Bar dataKey="green" stackId="a" fill="hsl(var(--risk-green))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
