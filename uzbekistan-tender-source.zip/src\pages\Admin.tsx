import { useTranslation } from "react-i18next";
import { DemoBadge } from "@/components/DemoBadge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Play, Settings2 } from "lucide-react";

export default function Admin() {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto px-4 py-12 space-y-8 max-w-5xl">
      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.admin")} <DemoBadge />
        </h1>
        <p className="text-muted-foreground">Tizim sozlamalari va ma'lumotlar boshqaruvi</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Data Mode</CardTitle>
            <CardDescription>Tizimda ko'rsatiladigan ma'lumotlar turini tanlang</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <Label htmlFor="demo-mode" className="flex flex-col gap-1">
                <span>Demo ma'lumotlar</span>
                <span className="font-normal text-xs text-muted-foreground">Faqat test ma'lumotlar ko'rsatiladi</span>
              </Label>
              <Switch id="demo-mode" checked={true} />
            </div>
            <div className="flex items-center justify-between opacity-50">
              <Label htmlFor="live-mode" className="flex flex-col gap-1">
                <span>Live API (Official)</span>
                <span className="font-normal text-xs text-muted-foreground">Rasmiy bazalardan olinadi</span>
              </Label>
              <Switch id="live-mode" checked={false} disabled />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Import boshqaruvi</CardTitle>
            <CardDescription>Mock/Demo ma'lumotlarni qayta yuklash</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button className="w-full" variant="outline">
              <Play className="w-4 h-4 mr-2 text-risk-green" />
              Demo importni ishga tushirish
            </Button>
            <Button className="w-full" variant="outline">
              <Settings2 className="w-4 h-4 mr-2" />
              Risk scoring qoidalarini sozlash
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
