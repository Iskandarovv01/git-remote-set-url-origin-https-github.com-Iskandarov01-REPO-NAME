import { Badge } from "@/components/ui/badge";
import { useTranslation } from "react-i18next";

export function DemoBadge() {
  const { t } = useTranslation();
  return (
    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800 ml-2 font-normal">
      {t("status.demo_data")}
    </Badge>
  );
}
