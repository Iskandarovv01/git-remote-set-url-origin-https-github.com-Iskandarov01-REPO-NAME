import { useTranslation } from "react-i18next";
import { Link, useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { Button } from "@/components/ui/button";
import { routes } from "@/shared/routes";
import { ShieldAlert, ArrowRight, ShieldCheck, Database, Lock, Scale, AlertTriangle, FileText, Users, Calculator, History, Search, Target, Briefcase, LayoutDashboard, DownloadCloud, Fingerprint, Activity, Clock } from "lucide-react";
import { RiskBadge } from "@/components/RiskBadge";
import { WarningCard } from "@/components/WarningCard";
import { DemoBadge } from "@/components/DemoBadge";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ResponsiveContainer, BarChart, Bar, CartesianGrid, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from "recharts";
import { MOCK_DASHBOARD } from "@/data/dashboard";

export default function Home() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language || "uz";

  const pieData = [
    { name: "Green", value: MOCK_DASHBOARD.greenRisks, color: "hsl(var(--risk-green))" },
    { name: "Yellow", value: MOCK_DASHBOARD.yellowRisks, color: "hsl(var(--risk-yellow))" },
    { name: "Red", value: MOCK_DASHBOARD.redRisks, color: "hsl(var(--risk-red))" }
  ];

  return (
    <div className="flex flex-col w-full">
      {/* SECTION 1 — HERO */}
      <section className="relative overflow-hidden bg-background border-b pt-12 pb-20 md:pt-20 md:pb-32">
        <div className="absolute inset-0 z-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        <div className="absolute left-0 right-0 top-0 -z-10 m-auto h-[310px] w-[310px] rounded-full bg-primary/20 opacity-20 blur-[100px]"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-8 items-center">
            
            {/* Left Col */}
            <div className="flex-1 space-y-8 max-w-2xl text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border bg-muted/50 text-sm font-medium text-muted-foreground">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                Uzbekistan Tender <DemoBadge />
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-foreground leading-tight">
                {t("home.hero.title")}
              </h1>
              
              <p className="text-lg text-muted-foreground leading-relaxed">
                {t("home.hero.subtitle")}
              </p>
              
              <WarningCard severity="info" className="text-left w-full max-w-xl mx-auto lg:mx-0">
                {t("home.hero.trust_note")}
              </WarningCard>
              
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-4">
                <Button asChild size="lg" className="h-12 px-8 text-base">
                  <LocalizedLink href={routes.tenders(locale)} data-testid="btn-view-tenders">
                    View tenders <ArrowRight className="ml-2 h-4 w-4" />
                  </LocalizedLink>
                </Button>
                <Button asChild variant="outline" size="lg" className="h-12 px-8 text-base">
                  <LocalizedLink href={routes.aiEngine(locale)}>
                    {t("nav.how_ai_works")}
                  </LocalizedLink>
                </Button>
                <Button asChild variant="ghost" size="lg" className="h-12 px-8 text-base hidden sm:flex">
                  <LocalizedLink href={routes.riskyTenders(locale)}>
                    {t("nav.risky_tenders")}
                  </LocalizedLink>
                </Button>
              </div>
            </div>

            {/* Right Col: Dashboard Preview */}
            <div className="flex-1 w-full max-w-xl lg:max-w-none">
              <div className="rounded-xl border bg-card text-card-foreground shadow-xl overflow-hidden flex flex-col">
                <div className="bg-muted px-4 py-3 border-b flex items-center gap-2">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-500/20 border border-amber-500/50"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50"></div>
                  </div>
                  <div className="ml-4 text-xs font-mono text-muted-foreground">Tender T-2025-001 • Risk Analysis</div>
                </div>
                
                <div className="p-6 md:p-8 flex flex-col gap-8">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-serif font-bold text-xl mb-1">Bino Qurilish Servis MChJ</h3>
                      <p className="text-sm text-muted-foreground">INN: ***-**-1234 • 4.4 mlrd UZS</p>
                    </div>
                    <div className="relative w-24 h-24 flex items-center justify-center rounded-full bg-risk-red/10 border-8 border-risk-red/20">
                      <span className="text-3xl font-bold text-risk-red">82</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/50">
                      <div className="flex items-center gap-3">
                        <Users className="h-4 w-4 text-risk-red" />
                        <span className="text-sm font-medium">Manfaatlar to'qnashuvi ehtimoli</span>
                      </div>
                      <RiskBadge level="red" />
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/50">
                      <div className="flex items-center gap-3">
                        <History className="h-4 w-4 text-risk-yellow" />
                        <span className="text-sm font-medium">Oldingi shartnomalarda kechikish</span>
                      </div>
                      <RiskBadge level="yellow" />
                    </div>
                  </div>
                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center text-xs text-muted-foreground font-medium">
                      <div className="flex flex-col items-center gap-1"><FileText className="h-4 w-4" /><span>Tender</span></div>
                      <div className="h-px w-8 bg-border"></div>
                      <div className="flex flex-col items-center gap-1"><Users className="h-4 w-4" /><span>Applicants</span></div>
                      <div className="h-px w-8 bg-border"></div>
                      <div className="flex flex-col items-center gap-1 text-primary"><Database className="h-4 w-4" /><span>AI analysis</span></div>
                      <div className="h-px w-8 bg-border"></div>
                      <div className="flex flex-col items-center gap-1 text-risk-red"><AlertTriangle className="h-4 w-4" /><span>Risk status</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* SECTION 2 — TRUST STRIP */}
      <section className="bg-muted py-12 border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-lg bg-background border flex flex-col gap-3">
              <ShieldCheck className="h-6 w-6 text-primary" />
              <h3 className="font-semibold">{t("home.trust.t1")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.trust.b1")}</p>
            </div>
            <div className="p-6 rounded-lg bg-background border flex flex-col gap-3">
              <Database className="h-6 w-6 text-risk-blue" />
              <h3 className="font-semibold">{t("home.trust.t2")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.trust.b2")}</p>
            </div>
            <div className="p-6 rounded-lg bg-background border flex flex-col gap-3">
              <Fingerprint className="h-6 w-6 text-risk-green" />
              <h3 className="font-semibold">{t("home.trust.t3")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.trust.b3")}</p>
            </div>
            <div className="p-6 rounded-lg bg-background border flex flex-col gap-3">
              <Scale className="h-6 w-6 text-risk-purple" />
              <h3 className="font-semibold">{t("home.trust.t4")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.trust.b4")}</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3 — WHY THIS IS NEEDED */}
      <section className="py-20 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.why.title")}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <Database className="h-8 w-8 text-primary mb-2" />
                <CardTitle>{t("home.why.t1")}</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                {t("home.why.b1")}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Calculator className="h-8 w-8 text-primary mb-2" />
                <CardTitle>{t("home.why.t2")}</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                {t("home.why.b2")}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <History className="h-8 w-8 text-primary mb-2" />
                <CardTitle>{t("home.why.t3")}</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                {t("home.why.b3")}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Target className="h-8 w-8 text-primary mb-2" />
                <CardTitle>{t("home.why.t4")}</CardTitle>
              </CardHeader>
              <CardContent className="text-muted-foreground">
                {t("home.why.b4")}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* SECTION 4 — HOW IT WORKS */}
      <section className="py-20 bg-muted/30 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.how.title")}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex flex-col gap-3 relative">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg mb-2">1</div>
              <h3 className="font-semibold">{t("home.how.s1_t")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.how.s1_b")}</p>
            </div>
            <div className="flex flex-col gap-3 relative">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg mb-2">2</div>
              <h3 className="font-semibold">{t("home.how.s2_t")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.how.s2_b")}</p>
            </div>
            <div className="flex flex-col gap-3 relative">
              <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg mb-2">3</div>
              <h3 className="font-semibold">{t("home.how.s3_t")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.how.s3_b")}</p>
            </div>
            <div className="flex flex-col gap-3 relative">
              <div className="w-12 h-12 rounded-full bg-risk-purple/10 text-risk-purple flex items-center justify-center font-bold text-lg mb-2">4</div>
              <h3 className="font-semibold">{t("home.how.s4_t")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.how.s4_b")}</p>
            </div>
            <div className="flex flex-col gap-3 relative">
              <div className="w-12 h-12 rounded-full bg-risk-red/10 text-risk-red flex items-center justify-center font-bold text-lg mb-2">5</div>
              <h3 className="font-semibold">{t("home.how.s5_t")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.how.s5_b")}</p>
            </div>
            <div className="flex flex-col gap-3 relative">
              <div className="w-12 h-12 rounded-full bg-risk-green/10 text-risk-green flex items-center justify-center font-bold text-lg mb-2">6</div>
              <h3 className="font-semibold">{t("home.how.s6_t")}</h3>
              <p className="text-sm text-muted-foreground">{t("home.how.s6_b")}</p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 5 — AI MODULES */}
      <section className="py-20 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.ai_modules.title")}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <Users className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">{t("home.ai_modules.t1")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{t("home.ai_modules.b1")}</p>
                <div className="text-xs text-muted-foreground/60 flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> {t("home.ai_modules.note")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Calculator className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">{t("home.ai_modules.t2")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{t("home.ai_modules.b2")}</p>
                <div className="text-xs text-muted-foreground/60 flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> {t("home.ai_modules.note")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Activity className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">{t("home.ai_modules.t3")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{t("home.ai_modules.b3")}</p>
                <div className="text-xs text-muted-foreground/60 flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> {t("home.ai_modules.note")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <History className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">{t("home.ai_modules.t4")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{t("home.ai_modules.b4")}</p>
                <div className="text-xs text-muted-foreground/60 flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> {t("home.ai_modules.note")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Briefcase className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">{t("home.ai_modules.t5")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{t("home.ai_modules.b5")}</p>
                <div className="text-xs text-muted-foreground/60 flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> {t("home.ai_modules.note")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <FileText className="h-6 w-6 text-primary mb-2" />
                <CardTitle className="text-lg">{t("home.ai_modules.t6")}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">{t("home.ai_modules.b6")}</p>
                <div className="text-xs text-muted-foreground/60 flex items-center gap-1"><AlertTriangle className="w-3 h-3"/> {t("home.ai_modules.note")}</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* SECTION 6 — RISK STATUS */}
      <section className="py-20 bg-muted/30 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.risk_status.title")}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="border-t-4 border-t-risk-green">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-risk-green"></span>
                  Yashil / Зелёный / Green
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{t("home.risk_status.green")}</p>
              </CardContent>
            </Card>
            <Card className="border-t-4 border-t-risk-yellow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-risk-yellow"></span>
                  Sariq / Жёлтый / Yellow
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{t("home.risk_status.yellow")}</p>
              </CardContent>
            </Card>
            <Card className="border-t-4 border-t-risk-red">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-risk-red"></span>
                  Qizil / Красный / Red
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{t("home.risk_status.red")}</p>
              </CardContent>
            </Card>
          </div>
          <p className="text-center text-sm text-muted-foreground italic max-w-2xl mx-auto">
            {t("home.risk_status.footer")}
          </p>
        </div>
      </section>

      {/* SECTION 7 — PUBLIC DASHBOARD PREVIEW */}
      <section className="py-20 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.dashboard_preview.title")}</h2>
            <p className="text-muted-foreground">{t("home.dashboard_preview.body")}</p>
          </div>
          <div className="grid gap-6 md:grid-cols-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{MOCK_DASHBOARD.totalTenders.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground mt-1">Total tenders</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-risk-red">{MOCK_DASHBOARD.redRisks.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground mt-1">Red risks</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-risk-yellow">{MOCK_DASHBOARD.yellowRisks.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground mt-1">Yellow risks</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{MOCK_DASHBOARD.highPriceDeviation.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground mt-1">High price deviation</p>
              </CardContent>
            </Card>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader><CardTitle className="text-sm text-muted-foreground">Risk status mix</CardTitle></CardHeader>
              <CardContent className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={2}>
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle className="text-sm text-muted-foreground">Risk by sector</CardTitle></CardHeader>
              <CardContent className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={MOCK_DASHBOARD.riskBySector}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                    <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Bar dataKey="red" stackId="a" fill="hsl(var(--risk-red))" />
                    <Bar dataKey="yellow" stackId="a" fill="hsl(var(--risk-yellow))" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          <div className="text-center mt-8">
            <Button asChild variant="outline">
              <LocalizedLink href={routes.publicDashboard(locale)}>{t("buttons.public_dashboard")} <ArrowRight className="ml-2 w-4 h-4"/></LocalizedLink>
            </Button>
          </div>
        </div>
      </section>

      {/* SECTION 8 — DATA QUALITY AND OFFICIAL SOURCES */}
      <section className="py-20 bg-muted/30 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.sources.title")}</h2>
            <p className="text-muted-foreground">{t("home.sources.body")}</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {['lex.uz', 'gov.uz', 'dxarid.uz', 'data.egov.uz'].map(source => (
              <Card key={source}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex justify-between items-center">
                    {source}
                    <ShieldCheck className="h-4 w-4 text-risk-green" />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RiskBadge level="demo" />
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button asChild variant="outline">
              <LocalizedLink href={routes.officialSources(locale)}>{t("buttons.official_sources")} <ArrowRight className="ml-2 w-4 h-4"/></LocalizedLink>
            </Button>
          </div>
        </div>
      </section>

      {/* SECTION 9 — SECURITY & PRIVACY */}
      <section className="py-20 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-serif font-bold mb-4">{t("home.security.title")}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <Lock className="w-6 h-6 text-primary mb-2" />
                <CardTitle className="text-base">{t("home.security.t1")}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">{t("home.security.b1")}</CardContent>
            </Card>
            <Card>
              <CardHeader>
                <History className="w-6 h-6 text-primary mb-2" />
                <CardTitle className="text-base">{t("home.security.t2")}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">{t("home.security.b2")}</CardContent>
            </Card>
            <Card>
              <CardHeader>
                <ShieldCheck className="w-6 h-6 text-primary mb-2" />
                <CardTitle className="text-base">{t("home.security.t3")}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">{t("home.security.b3")}</CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Database className="w-6 h-6 text-primary mb-2" />
                <CardTitle className="text-base">{t("home.security.t4")}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">{t("home.security.b4")}</CardContent>
            </Card>
            <Card>
              <CardHeader>
                <LayoutDashboard className="w-6 h-6 text-primary mb-2" />
                <CardTitle className="text-base">{t("home.security.t5")}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">{t("home.security.b5")}</CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* SECTION 10 — FINAL CTA */}
      <section className="py-24 bg-primary text-primary-foreground text-center">
        <div className="container mx-auto px-4 max-w-4xl space-y-8">
          <h2 className="text-4xl md:text-5xl font-serif font-bold">{t("home.cta.title")}</h2>
          <p className="text-xl opacity-90 leading-relaxed max-w-3xl mx-auto">
            {t("home.cta.body")}
          </p>
          <div className="flex flex-wrap justify-center gap-4 pt-8">
            <Button asChild size="lg" variant="secondary" className="h-14 px-8 text-lg font-medium text-primary hover:text-primary">
              <LocalizedLink href={routes.tenders(locale)}>
                {t("nav.tenders")}
              </LocalizedLink>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-14 px-8 text-lg font-medium bg-transparent border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground">
              <LocalizedLink href={routes.publicDashboard(locale)}>
                {t("nav.public_dashboard")}
              </LocalizedLink>
            </Button>
          </div>
        </div>
      </section>

    </div>
  );
}
