import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Globe } from "lucide-react";
import { useLocation } from "wouter";

export function LanguageSwitcher() {
  const { t, i18n } = useTranslation();
  const [location, setLocation] = useLocation();

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    
    // Update URL if it starts with the old locale
    const segments = location.split('/');
    if (segments.length > 1 && ['uz', 'ru', 'en'].includes(segments[1])) {
      segments[1] = lng;
      setLocation(segments.join('/') || '/');
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full" data-testid="select-language">
          <Globe className="h-4 w-4 text-muted-foreground" />
          <span className="sr-only">Toggle language</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => changeLanguage('uz')} data-testid="lang-uz">
          O'zbek
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => changeLanguage('ru')} data-testid="lang-ru">
          Русский
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => changeLanguage('en')} data-testid="lang-en">
          English
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
