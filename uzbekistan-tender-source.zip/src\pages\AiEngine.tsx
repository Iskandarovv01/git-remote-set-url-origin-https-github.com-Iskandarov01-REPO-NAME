import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { DemoBadge } from "@/components/DemoBadge";
import { WarningCard } from "@/components/WarningCard";
import { AlertTriangle, FileText, Activity, Server, Settings, ShieldCheck, Database } from "lucide-react";

export default function AiEngine() {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl space-y-12">
      <div>
        <h1 className="text-4xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.how_ai_works")}
        </h1>
        <p className="text-xl text-muted-foreground">
          {t("intro.ai_engine")}
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <div className="border p-6 rounded-lg bg-card">
          <AlertTriangle className="h-8 w-8 text-primary mb-4" />
          <h3 className="font-bold text-lg mb-2">{t("home.ai_modules.t1")}</h3>
          <p className="text-sm text-muted-foreground">{t("home.ai_modules.b1")}</p>
        </div>
        <div className="border p-6 rounded-lg bg-card">
          <Activity className="h-8 w-8 text-primary mb-4" />
          <h3 className="font-bold text-lg mb-2">{t("home.ai_modules.t2")}</h3>
          <p className="text-sm text-muted-foreground">{t("home.ai_modules.b2")}</p>
        </div>
        <div className="border p-6 rounded-lg bg-card">
          <FileText className="h-8 w-8 text-primary mb-4" />
          <h3 className="font-bold text-lg mb-2">{t("home.ai_modules.t3")}</h3>
          <p className="text-sm text-muted-foreground">{t("home.ai_modules.b3")}</p>
        </div>
        <div className="border p-6 rounded-lg bg-card">
          <Server className="h-8 w-8 text-primary mb-4" />
          <h3 className="font-bold text-lg mb-2">{t("home.ai_modules.t4")}</h3>
          <p className="text-sm text-muted-foreground">{t("home.ai_modules.b4")}</p>
        </div>
        <div className="border p-6 rounded-lg bg-card">
          <Settings className="h-8 w-8 text-primary mb-4" />
          <h3 className="font-bold text-lg mb-2">{t("home.ai_modules.t5")}</h3>
          <p className="text-sm text-muted-foreground">{t("home.ai_modules.b5")}</p>
        </div>
        <div className="border p-6 rounded-lg bg-card">
          <Database className="h-8 w-8 text-primary mb-4" />
          <h3 className="font-bold text-lg mb-2">{t("home.ai_modules.t6")}</h3>
          <p className="text-sm text-muted-foreground">{t("home.ai_modules.b6")}</p>
        </div>
      </div>
    </div>
  );
}
