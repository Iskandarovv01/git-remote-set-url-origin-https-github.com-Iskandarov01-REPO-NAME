import { useTranslation } from "react-i18next";
import { DemoBadge } from "@/components/DemoBadge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Lock, FileText, Database, ShieldCheck } from "lucide-react";

export default function SecurityPrivacy() {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl space-y-12">
      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.security_privacy")}
        </h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <Lock className="h-6 w-6 text-primary mb-2" />
            <CardTitle>{t("home.security.t1")}</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground text-sm">
            {t("home.security.b1")}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <FileText className="h-6 w-6 text-primary mb-2" />
            <CardTitle>{t("home.security.t2")}</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground text-sm">
            {t("home.security.b2")}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <ShieldCheck className="h-6 w-6 text-primary mb-2" />
            <CardTitle>{t("home.security.t3")}</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground text-sm">
            {t("home.security.b3")}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Database className="h-6 w-6 text-primary mb-2" />
            <CardTitle>{t("home.security.t4")}</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground text-sm">
            {t("home.security.b4")}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
