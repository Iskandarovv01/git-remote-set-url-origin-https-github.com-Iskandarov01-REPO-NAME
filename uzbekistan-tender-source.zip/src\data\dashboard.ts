export const MOCK_DASHBOARD = {
  totalTenders: 12450,
  aiChecked: 12450,
  redRisks: 1542,
  yellowRisks: 3876,
  greenRisks: 7032,
  highPriceDeviation: 845,
  dataQuality: {
    complete: 85,
    partial: 12,
    missing: 3
  },
  riskBySector: [
    { name: "Qurilish", red: 450, yellow: 820, green: 1200 },
    { name: "Sog'liqni saqlash", red: 320, yellow: 650, green: 1100 },
    { name: "Ta'lim", red: 210, yellow: 540, green: 1400 },
    { name: "IT", red: 85, yellow: 210, green: 950 },
    { name: "Energetika", red: 280, yellow: 430, green: 850 },
    { name: "Transport", red: 197, yellow: 526, green: 1532 }
  ],
  trendData: [
    { month: "Yan", riskScore: 42, deviation: 12 },
    { month: "Fev", riskScore: 45, deviation: 14 },
    { month: "Mar", riskScore: 38, deviation: 10 },
    { month: "Apr", riskScore: 35, deviation: 9 },
    { month: "May", riskScore: 31, deviation: 7 },
    { month: "Iyun", riskScore: 32, deviation: 8 }
  ]
};
