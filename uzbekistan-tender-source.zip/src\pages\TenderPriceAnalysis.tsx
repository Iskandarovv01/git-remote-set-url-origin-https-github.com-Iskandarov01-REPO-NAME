import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { MOCK_TENDERS } from "@/data/tenders";
import { DemoBadge } from "@/components/DemoBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export default function TenderPriceAnalysis() {
  const { t, i18n } = useTranslation();
  const [, params] = useRoute("/:locale/tenders/:id/price-analysis");
  const tenderId = params?.id;

  const tender = MOCK_TENDERS.find(t => t.id === tenderId) || MOCK_TENDERS[0];
  
  const priceData = [
    { name: "Bozor o'rtacha", price: tender.amount * 0.95 },
    { name: "Kutilgan", price: tender.amount },
    ...tender.applicants.map((app) => ({
      name: app.name.substring(0, 15) + "...",
      price: app.offerAmount
    }))
  ];

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <Button variant="ghost" asChild className="pl-0 hover:bg-transparent">
          <LocalizedLink href={`/tenders/${tender.id}`}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Tenderga qaytish
          </LocalizedLink>
        </Button>
        <DemoBadge />
      </div>

      <div>
        <h1 className="text-3xl font-serif font-bold mb-2">Narx tahlili</h1>
        <p className="text-muted-foreground">Taklif qilingan narxlarni bozor o'rtachasi va kutilgan narx bilan solishtirish</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Solishtirma narxlar (UZS)</CardTitle>
        </CardHeader>
        <CardContent className="h-[500px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={priceData} layout="vertical" margin={{ top: 20, right: 30, left: 40, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} opacity={0.3} />
              <XAxis type="number" tickFormatter={(val) => `${(val / 1000000000).toFixed(1)} mlrd`} fontSize={12} />
              <YAxis dataKey="name" type="category" width={120} fontSize={12} />
              <Tooltip formatter={(value: number) => new Intl.NumberFormat('uz-UZ').format(value) + ' UZS'} />
              <Bar dataKey="price" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
