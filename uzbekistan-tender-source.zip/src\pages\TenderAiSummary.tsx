import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { MOCK_TENDERS } from "@/data/tenders";
import { DemoBadge } from "@/components/DemoBadge";
import { WarningCard } from "@/components/WarningCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, AlertTriangle } from "lucide-react";

export default function TenderAiSummary() {
  const { t, i18n } = useTranslation();
  const [, params] = useRoute("/:locale/tenders/:id/ai-summary");
  const tenderId = params?.id;

  const tender = MOCK_TENDERS.find(t => t.id === tenderId) || MOCK_TENDERS[0];
  const highRiskApplicants = tender.applicants.filter(a => a.riskLevel === "red");

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl space-y-8">
      <div className="flex items-center justify-between">
        <Button variant="ghost" asChild className="pl-0 hover:bg-transparent">
          <LocalizedLink href={`/tenders/${tender.id}`}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Tenderga qaytish
          </LocalizedLink>
        </Button>
        <DemoBadge />
      </div>

      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          AI Xulosa: {tender.title}
        </h1>
      </div>

      <WarningCard severity="warning" title={t("home.hero.trust_note")}>
        AI faqat ochiq va mavjud ma'lumotlarga asoslanib tahlil qiladi. Yakuniy huquqiy qarorlar inson tomonidan qabul qilinishi lozim.
      </WarningCard>

      <Card className="border-t-4 border-t-primary">
        <CardHeader>
          <CardTitle>Umumiy tahlil natijasi</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col md:flex-row gap-8 items-center bg-muted/30 p-6 rounded-lg border">
            <div className="relative w-32 h-32 flex items-center justify-center rounded-full border-8 border-primary/20 shrink-0">
              <div className="text-center">
                <span className="text-4xl font-bold text-primary">{tender.riskScore}</span>
                <div className="text-xs font-semibold text-muted-foreground uppercase mt-1">/ 100 ball</div>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2">Tenderning umumiy risk darajasi: {tender.riskLevel.toUpperCase()}</h3>
              <p className="text-muted-foreground">
                Tenderda {tender.applicants.length} ta ishtirokchi qatnashmoqda. Ulardan {highRiskApplicants.length} tasida yuqori risk signallari aniqlangan. 
                Narxlar bozor o'rtachasiga nisbatan farq qilishi mumkin.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Asosiy signallar:</h4>
            {tender.applicants.flatMap(app => 
              app.signals.map((sig, idx) => (
                <div key={`${app.id}-${idx}`} className="flex items-start gap-3 p-4 rounded-md border bg-card">
                  <AlertTriangle className="w-5 h-5 text-risk-red shrink-0 mt-0.5" />
                  <div>
                    <div className="font-semibold">{sig.type.toUpperCase()}: {app.name}</div>
                    <div className="text-sm text-muted-foreground">{sig.description}</div>
                  </div>
                </div>
              ))
            )}
            {tender.applicants.every(a => a.signals.length === 0) && (
              <div className="p-4 text-center text-muted-foreground border rounded-md">
                Jiddiy risk signallari aniqlanmadi
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
