import { useTranslation } from "react-i18next";
import { DemoBadge } from "@/components/DemoBadge";
import { MOCK_SOURCES } from "@/data/sources";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";

export default function DataQuality() {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto px-4 py-12 space-y-8 max-w-5xl">
      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.data_quality")} <DemoBadge />
        </h1>
        <p className="text-muted-foreground">Ma'lumotlar manbalarining yangilanish holati va sifati.</p>
      </div>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Manba</TableHead>
              <TableHead>Sinxronizatsiya</TableHead>
              <TableHead>Ma'lumot to'liqligi</TableHead>
              <TableHead>Holati</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {MOCK_SOURCES.map(source => (
              <TableRow key={source.id}>
                <TableCell className="font-medium">{source.name}</TableCell>
                <TableCell className="text-sm text-muted-foreground font-mono">{source.lastSync}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Progress value={source.completeness} className="w-[100px]" />
                    <span className="text-xs font-medium">{source.completeness}%</span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className={`text-xs font-semibold px-2 py-1 rounded ${
                    source.status === 'active' ? 'bg-risk-green/10 text-risk-green' :
                    source.status === 'snapshot' ? 'bg-risk-yellow/10 text-risk-yellow' :
                    'bg-risk-blue/10 text-risk-blue'
                  }`}>
                    {source.status.toUpperCase()}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
