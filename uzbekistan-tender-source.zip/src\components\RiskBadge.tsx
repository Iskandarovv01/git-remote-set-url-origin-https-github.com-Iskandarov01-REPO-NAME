import { Badge } from "@/components/ui/badge";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";

export type RiskLevel = "green" | "yellow" | "red" | "data_quality" | "demo";

interface RiskBadgeProps {
  level: RiskLevel;
  className?: string;
  showText?: boolean;
}

export function RiskBadge({ level, className, showText = true }: RiskBadgeProps) {
  const { t } = useTranslation();

  const config = {
    green: {
      color: "bg-risk-green/10 text-risk-green hover:bg-risk-green/20 border-risk-green/20",
      text: t("status.green"),
    },
    yellow: {
      color: "bg-risk-yellow/10 text-risk-yellow hover:bg-risk-yellow/20 border-risk-yellow/20",
      text: t("status.yellow"),
    },
    red: {
      color: "bg-risk-red/10 text-risk-red hover:bg-risk-red/20 border-risk-red/20",
      text: t("status.red"),
    },
    data_quality: {
      color: "bg-risk-gray/10 text-risk-gray hover:bg-risk-gray/20 border-risk-gray/20",
      text: t("status.data_quality"),
    },
    demo: {
      color: "bg-risk-blue/10 text-risk-blue hover:bg-risk-blue/20 border-risk-blue/20",
      text: t("status.demo"),
    },
  };

  const { color, text } = config[level] || config.demo;

  return (
    <Badge 
      variant="outline" 
      className={cn("font-medium transition-colors cursor-default whitespace-nowrap", color, className)}
      data-testid={`badge-risk-${level}`}
    >
      {showText ? text : level.toUpperCase()}
    </Badge>
  );
}
