import { Link, useRoute } from "wouter";
import { ReactNode } from "react";
import { useTranslation } from "react-i18next";

interface LocalizedLinkProps {
  href: string;
  children: ReactNode;
  className?: string;
  "data-testid"?: string;
}

export function LocalizedLink({ href, children, className, "data-testid": testId }: LocalizedLinkProps) {
  const { i18n } = useTranslation();
  const currentLang = i18n.language || "uz";
  
  // Ensure the href doesn't already start with a locale if we're passing a raw path like "/tenders"
  const cleanHref = href.startsWith("/") ? href : `/${href}`;
  const localizedPath = cleanHref.startsWith(`/${currentLang}`) 
    ? cleanHref 
    : `/${currentLang}${cleanHref}`;

  return (
    <Link href={localizedPath} className={className} data-testid={testId}>
      {children}
    </Link>
  );
}
