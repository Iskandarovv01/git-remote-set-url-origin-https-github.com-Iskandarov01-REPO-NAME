import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { ThemeToggle } from "./ThemeToggle";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { LocalizedLink } from "./LocalizedLink";
import { Button } from "./ui/button";
import { Menu, ShieldAlert } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "./ui/sheet";
import { routes } from "@/shared/routes";
import { useState } from "react";

export function Header() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language || "uz";
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location === path || location.startsWith(`${path}/`);
  };

  const navItems = [
    { label: t("nav.home"), path: routes.home(locale), exact: true },
    { label: t("nav.tenders"), path: routes.tenders(locale) },
    { label: t("nav.public_dashboard"), path: routes.publicDashboard(locale) },
    { label: t("nav.reports"), path: routes.reports(locale) },
    { label: t("nav.how_ai_works"), path: routes.aiEngine(locale) },
  ];

  const moreItems = [
    { label: t("nav.risky_tenders"), path: routes.riskyTenders(locale) },
    { label: t("nav.official_sources"), path: routes.officialSources(locale) },
    { label: t("nav.data_quality"), path: routes.dataQuality(locale) },
    { label: t("nav.admin"), path: routes.admin(locale) },
    { label: t("nav.audit_log"), path: routes.auditLog(locale) },
    { label: t("nav.security_privacy"), path: routes.securityPrivacy(locale) },
    { label: t("nav.integrations"), path: routes.integrations(locale) },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-6 md:gap-10">
          <Link href={`/${locale}`} className="flex items-center gap-2">
            <ShieldAlert className="h-6 w-6 text-primary" />
            <span className="font-serif font-bold text-lg hidden sm:inline-block">
              Uzbekistan Tender
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                href={item.path}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  (item.exact ? location === item.path : isActive(item.path)) 
                    ? "text-primary" 
                    : "text-muted-foreground"
                }`}
              >
                {item.label}
              </Link>
            ))}
            
            <DropdownMenu>
              <DropdownMenuTrigger className="text-sm font-medium text-muted-foreground hover:text-primary flex items-center gap-1 outline-none">
                {t("nav.more")}
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                {moreItems.map((item) => (
                  <DropdownMenuItem key={item.path} asChild>
                    <Link href={item.path} className="w-full cursor-pointer">
                      {item.label}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-2">
            <LanguageSwitcher />
            <ThemeToggle />
          </div>

          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full max-w-sm flex flex-col">
              <div className="flex items-center gap-2 mb-8 mt-4">
                <ShieldAlert className="h-6 w-6 text-primary" />
                <span className="font-serif font-bold text-lg">Uzbekistan Tender</span>
              </div>
              
              <nav className="flex flex-col gap-4 flex-1 overflow-y-auto">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Asosiy sahifalar</div>
                {navItems.map((item) => (
                  <Link 
                    key={item.path} 
                    href={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`text-base font-medium ${
                      (item.exact ? location === item.path : isActive(item.path)) 
                        ? "text-primary" 
                        : "text-foreground"
                    }`}
                  >
                    {item.label}
                  </Link>
                ))}
                
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 mt-4">Boshqa bo'limlar</div>
                {moreItems.map((item) => (
                  <Link 
                    key={item.path} 
                    href={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-base font-medium text-foreground"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>

              <div className="flex items-center gap-4 mt-auto pt-4 border-t">
                <LanguageSwitcher />
                <ThemeToggle />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
