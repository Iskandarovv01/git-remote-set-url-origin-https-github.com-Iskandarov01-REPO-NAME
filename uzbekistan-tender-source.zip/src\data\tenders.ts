export interface Applicant {
  id: string;
  name: string;
  inn: string;
  offerAmount: number;
  riskScore: number;
  riskLevel: "green" | "yellow" | "red";
  signals: {
    type: string;
    description: string;
  }[];
}

export interface Tender {
  id: string;
  title: string;
  customer: string;
  amount: number;
  currency: string;
  sector: string;
  region: string;
  publishDate: string;
  deadline: string;
  status: "active" | "closed" | "cancelled";
  riskScore: number;
  riskLevel: "green" | "yellow" | "red";
  applicants: Applicant[];
}

export const MOCK_TENDERS: Tender[] = [
  {
    id: "T-2025-001",
    title: "1-sonli maktab binosini mukammal ta'mirlash",
    customer: "Xalq ta'limi vazirligi",
    amount: 4500000000,
    currency: "UZS",
    sector: "qurilish",
    region: "Tashkent",
    publishDate: "2025-02-15",
    deadline: "2025-03-15",
    status: "active",
    riskScore: 78,
    riskLevel: "red",
    applicants: [
      {
        id: "ORG-101",
        name: "Bino Qurilish Servis MChJ",
        inn: "***-**-1234",
        offerAmount: 4400000000,
        riskScore: 82,
        riskLevel: "red",
        signals: [
          { type: "conflict", description: "Manfaatlar to'qnashuvi ehtimoli (rahbarlar bir xil manzilda ro'yxatdan o'tgan)" },
          { type: "experience", description: "Shu hajmrdagi loyihalar tajribasi yetarli emas" }
        ]
      },
      {
        id: "ORG-102",
        name: "Qurilish Standart Plus",
        inn: "***-**-5678",
        offerAmount: 4600000000,
        riskScore: 25,
        riskLevel: "green",
        signals: []
      }
    ]
  },
  {
    id: "T-2025-002",
    title: "Tibbiyot uskunalari va jihozlarini xarid qilish",
    customer: "Sog'liqni saqlash vazirligi",
    amount: 12000000000,
    currency: "UZS",
    sector: "sog'liqni saqlash",
    region: "Samarqand",
    publishDate: "2025-02-10",
    deadline: "2025-03-10",
    status: "active",
    riskScore: 45,
    riskLevel: "yellow",
    applicants: [
      {
        id: "ORG-201",
        name: "MedTech Supply",
        inn: "***-**-9012",
        offerAmount: 11800000000,
        riskScore: 50,
        riskLevel: "yellow",
        signals: [
          { type: "price", description: "Taklif narxi bozor o'rtachasidan 15% yuqori" }
        ]
      }
    ]
  },
  {
    id: "T-2025-003",
    title: "Axborot tizimini ishlab chiqish va joriy etish",
    customer: "Raqamli texnologiyalar vazirligi",
    amount: 850000000,
    currency: "UZS",
    sector: "IT",
    region: "Tashkent",
    publishDate: "2025-01-20",
    deadline: "2025-02-20",
    status: "closed",
    riskScore: 15,
    riskLevel: "green",
    applicants: [
      {
        id: "ORG-301",
        name: "SoftDev Solutions",
        inn: "***-**-3456",
        offerAmount: 820000000,
        riskScore: 12,
        riskLevel: "green",
        signals: []
      },
      {
        id: "ORG-302",
        name: "Tech Innovation Group",
        inn: "***-**-7890",
        offerAmount: 840000000,
        riskScore: 20,
        riskLevel: "green",
        signals: []
      }
    ]
  },
  {
    id: "T-2025-004",
    title: "Yangi transformator podstansiyasini qurish",
    customer: "Hududiy elektr tarmoqlari AJ",
    amount: 25000000000,
    currency: "UZS",
    sector: "energetika",
    region: "Bukhara",
    publishDate: "2025-02-01",
    deadline: "2025-03-01",
    status: "active",
    riskScore: 65,
    riskLevel: "red",
    applicants: [
      {
        id: "ORG-401",
        name: "Energo Qurilish Invest",
        inn: "***-**-1111",
        offerAmount: 24500000000,
        riskScore: 70,
        riskLevel: "red",
        signals: [
          { type: "history", description: "Oldingi 2 ta shartnoma bekor qilingan" },
          { type: "tax", description: "Soliq qarzdorligi xavfi signali (demo)" }
        ]
      }
    ]
  },
  {
    id: "T-2025-005",
    title: "Qishloq xo'jaligi texnikalarini yetkazib berish",
    customer: "Qishloq xo'jaligi vazirligi",
    amount: 5000000000,
    currency: "UZS",
    sector: "transport",
    region: "Sirdaryo",
    publishDate: "2025-02-18",
    deadline: "2025-03-18",
    status: "active",
    riskScore: 35,
    riskLevel: "yellow",
    applicants: [
      {
        id: "ORG-501",
        name: "AgroTexnika MChJ",
        inn: "***-**-2222",
        offerAmount: 4900000000,
        riskScore: 40,
        riskLevel: "yellow",
        signals: [
          { type: "document", description: "Texnik hujjatlarda noaniqliklar mavjud" }
        ]
      }
    ]
  },
  {
    id: "T-2025-006",
    title: "Viloyat markaziy ko'chalarini yoritish tizimini modernizatsiya qilish",
    customer: "Obodonlashtirish boshqarmasi",
    amount: 3200000000,
    currency: "UZS",
    sector: "energetika",
    region: "Andijan",
    publishDate: "2025-02-05",
    deadline: "2025-03-05",
    status: "active",
    riskScore: 22,
    riskLevel: "green",
    applicants: [
      {
        id: "ORG-601",
        name: "Yorug'lik Servis",
        inn: "***-**-3333",
        offerAmount: 3150000000,
        riskScore: 18,
        riskLevel: "green",
        signals: []
      },
      {
        id: "ORG-602",
        name: "Nurli Yo'l",
        inn: "***-**-4444",
        offerAmount: 3100000000,
        riskScore: 28,
        riskLevel: "green",
        signals: []
      }
    ]
  },
  {
    id: "T-2025-007",
    title: "Oliy ta'lim muassasalari uchun o'quv laboratoriya jihozlari",
    customer: "Oliy ta'lim, fan va innovatsiyalar vazirligi",
    amount: 7800000000,
    currency: "UZS",
    sector: "ta'lim",
    region: "Tashkent",
    publishDate: "2025-02-12",
    deadline: "2025-03-12",
    status: "active",
    riskScore: 55,
    riskLevel: "yellow",
    applicants: [
      {
        id: "ORG-701",
        name: "LabTech Pro",
        inn: "***-**-5555",
        offerAmount: 7600000000,
        riskScore: 58,
        riskLevel: "yellow",
        signals: [
          { type: "history", description: "Oldingi shartnomalar bo'yicha 2 marta kechikish kuzatilgan" }
        ]
      }
    ]
  }
];
