import { useTranslation } from "react-i18next";
import { DemoBadge } from "@/components/DemoBadge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const LOGS = [
  { id: 1, action: "Import tenders", actor: "System", date: "2025-02-28 14:32:01" },
  { id: 2, action: "AI Scoring", actor: "AI Engine", date: "2025-02-28 14:35:12" },
  { id: 3, action: "Export report", actor: "Admin", date: "2025-02-28 15:10:44" },
  { id: 4, action: "Update threshold", actor: "Admin", date: "2025-02-28 16:05:00" },
];

export default function AuditLog() {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto px-4 py-12 space-y-8 max-w-5xl">
      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.audit_log")} <DemoBadge />
        </h1>
      </div>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Date/Time</TableHead>
              <TableHead>Actor</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {LOGS.map(log => (
              <TableRow key={log.id}>
                <TableCell className="font-mono text-xs">{log.id}</TableCell>
                <TableCell className="font-mono text-xs">{log.date}</TableCell>
                <TableCell>{log.actor}</TableCell>
                <TableCell>{log.action}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
