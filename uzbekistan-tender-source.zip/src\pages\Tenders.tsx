import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { MOCK_TENDERS } from "@/data/tenders";
import { RiskBadge } from "@/components/RiskBadge";
import { LocalizedLink } from "@/components/LocalizedLink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Filter, SlidersHorizontal, ChevronDown } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { DemoBadge } from "@/components/DemoBadge";

export default function Tenders() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language || "uz";

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold flex items-center gap-3">
            {t("nav.tenders")} <DemoBadge />
          </h1>
          <p className="text-muted-foreground mt-2 max-w-3xl">
            {t("intro.tenders")}
          </p>
        </div>
      </div>

      <Card className="bg-muted/30">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Qidirish (Nomi yoki ID)" className="pl-9 bg-background" />
            </div>
            
            <Select>
              <SelectTrigger className="w-full md:w-[180px] bg-background">
                <SelectValue placeholder="Soha" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Barchasi</SelectItem>
                <SelectItem value="qurilish">Qurilish</SelectItem>
                <SelectItem value="soglik">Sog'liqni saqlash</SelectItem>
                <SelectItem value="it">IT</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger className="w-full md:w-[180px] bg-background">
                <SelectValue placeholder="Risk status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Barchasi</SelectItem>
                <SelectItem value="red">Qizil</SelectItem>
                <SelectItem value="yellow">Sariq</SelectItem>
                <SelectItem value="green">Yashil</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" className="bg-background shrink-0">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              {t("buttons.filter")}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>Tender nomi</TableHead>
              <TableHead>Buyurtmachi / Soha</TableHead>
              <TableHead className="text-right">Summa</TableHead>
              <TableHead className="text-center">Risk status</TableHead>
              <TableHead className="text-right">Amallar</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {MOCK_TENDERS.map((tender) => (
              <TableRow key={tender.id}>
                <TableCell className="font-mono text-xs">{tender.id}</TableCell>
                <TableCell className="font-medium">
                  {tender.title}
                  <div className="text-xs text-muted-foreground mt-1">Muddat: {tender.deadline}</div>
                </TableCell>
                <TableCell>
                  {tender.customer}
                  <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wider">{tender.sector}</div>
                </TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  {new Intl.NumberFormat('uz-UZ').format(tender.amount)} {tender.currency}
                </TableCell>
                <TableCell className="text-center">
                  <RiskBadge level={tender.riskLevel} />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end items-center gap-2">
                    <Button asChild size="sm" variant="outline">
                      <LocalizedLink href={`/tenders/${tender.id}`}>
                        {t("buttons.details")}
                      </LocalizedLink>
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <ChevronDown className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <LocalizedLink href={`/tenders/${tender.id}/ai-summary`} className="w-full cursor-pointer">
                            {t("buttons.ai_summary")}
                          </LocalizedLink>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <LocalizedLink href={`/tenders/${tender.id}/applicants`} className="w-full cursor-pointer">
                            Talabgorlar
                          </LocalizedLink>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <LocalizedLink href={`/tenders/${tender.id}/price-analysis`} className="w-full cursor-pointer">
                            {t("buttons.price_analysis")}
                          </LocalizedLink>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <LocalizedLink href={`/tenders/${tender.id}/evidence`} className="w-full cursor-pointer">
                            {t("buttons.evidence")}
                          </LocalizedLink>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
