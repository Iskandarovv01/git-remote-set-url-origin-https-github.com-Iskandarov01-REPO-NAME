import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";
import "./i18n/config";

import Home from "@/pages/Home";
import Tenders from "@/pages/Tenders";
import TenderDetail from "@/pages/TenderDetail";
import TenderApplicants from "@/pages/TenderApplicants";
import TenderAiSummary from "@/pages/TenderAiSummary";
import TenderEvidence from "@/pages/TenderEvidence";
import TenderPriceAnalysis from "@/pages/TenderPriceAnalysis";
import OrganizationPassport from "@/pages/OrganizationPassport";
import AiEngine from "@/pages/AiEngine";
import PublicDashboard from "@/pages/PublicDashboard";
import SecurityPrivacy from "@/pages/SecurityPrivacy";
import AuditLog from "@/pages/AuditLog";
import Reports from "@/pages/Reports";
import OfficialSources from "@/pages/OfficialSources";
import DataQuality from "@/pages/DataQuality";
import Admin from "@/pages/Admin";

const queryClient = new QueryClient();

function DummyPage({ title }: { title: string }) {
  return <div className="p-12 text-center font-serif text-2xl">{title}</div>;
}

const LOCALES = ['uz', 'ru', 'en'] as const;
type Locale = typeof LOCALES[number];

function isLocale(value: string | null | undefined): value is Locale {
  return !!value && (LOCALES as readonly string[]).includes(value);
}

function getDefaultLocale(): Locale {
  const saved = localStorage.getItem('uzt.locale');
  if (isLocale(saved)) return saved;
  // Try to detect from browser navigator (use only the primary tag, e.g. "en-US" -> "en")
  if (typeof navigator !== 'undefined' && navigator.language) {
    const primary = navigator.language.toLowerCase().split('-')[0];
    if (isLocale(primary)) return primary;
  }
  return 'uz';
}

function LocaleRouter() {
  const [location, setLocation] = useLocation();
  const { i18n } = useTranslation();

  useEffect(() => {
    const parts = location.split('/').filter(Boolean);
    const currentLocale = parts[0];

    // Redirect / (empty) to /<default-locale>
    if (parts.length === 0) {
      const target = `/${getDefaultLocale()}`;
      if (location !== target) setLocation(target, { replace: true });
      return;
    }

    // Invalid locale prefix → prepend default locale
    if (!isLocale(currentLocale)) {
      const target = `/${getDefaultLocale()}${location.startsWith('/') ? location : `/${location}`}`;
      if (location !== target) setLocation(target, { replace: true });
      return;
    }

    // Persist the (now valid) locale and sync i18n
    localStorage.setItem('uzt.locale', currentLocale);
    if (i18n.language !== currentLocale) {
      i18n.changeLanguage(currentLocale);
    }
  }, [location, i18n, setLocation]);

  const parts = location.split('/').filter(Boolean);
  if (parts.length === 0) return null;

  return (
    <Layout>
      <Switch>
        <Route path="/:locale" component={Home} />
        <Route path="/:locale/tenders" component={Tenders} />
        <Route path="/:locale/risky-tenders" component={() => <Tenders />} />
        <Route path="/:locale/tenders/:id" component={TenderDetail} />
        <Route path="/:locale/tenders/:id/applicants" component={TenderApplicants} />
        <Route path="/:locale/tenders/:id/ai-summary" component={TenderAiSummary} />
        <Route path="/:locale/tenders/:id/evidence" component={TenderEvidence} />
        <Route path="/:locale/tenders/:id/price-analysis" component={TenderPriceAnalysis} />
        <Route path="/:locale/organizations/:id" component={OrganizationPassport} />
        
        <Route path="/:locale/ai-engine" component={AiEngine} />
        <Route path="/:locale/public-dashboard" component={PublicDashboard} />
        <Route path="/:locale/reports" component={Reports} />
        <Route path="/:locale/official-sources" component={OfficialSources} />
        <Route path="/:locale/data-quality" component={DataQuality} />
        <Route path="/:locale/admin" component={Admin} />
        <Route path="/:locale/audit-log" component={AuditLog} />
        <Route path="/:locale/security-privacy" component={SecurityPrivacy} />
        <Route path="/:locale/integrations" component={() => <DummyPage title="Integrations" />} />
        
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="uzt.theme">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <LocaleRouter />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
