import { useTranslation } from "react-i18next";
import { Link, useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { MOCK_TENDERS } from "@/data/tenders";
import { DemoBadge } from "@/components/DemoBadge";
import { RiskBadge } from "@/components/RiskBadge";
import { WarningCard } from "@/components/WarningCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, Users, FileText, BrainCircuit, LineChart, Building2, Search, Target } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export default function TenderDetail() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language || "uz";
  const [, params] = useRoute("/:locale/tenders/:id");
  const tenderId = params?.id;

  const tender = MOCK_TENDERS.find(t => t.id === tenderId) || MOCK_TENDERS[0];

  // Mock data for price analysis chart
  const priceData = [
    { name: "Bozor o'rtacha", price: tender.amount * 0.95 },
    { name: "Kutilgan", price: tender.amount },
    ...tender.applicants.map((app, idx) => ({
      name: app.name.substring(0, 15) + "...",
      price: app.offerAmount
    }))
  ];

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <Button variant="ghost" asChild className="pl-0 hover:bg-transparent">
          <LocalizedLink href="/tenders">
            <ArrowLeft className="mr-2 h-4 w-4" /> Tenderlar ro'yxatiga qaytish
          </LocalizedLink>
        </Button>
        <DemoBadge />
      </div>

      <div className="flex flex-col md:flex-row gap-6 justify-between items-start">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <span className="text-sm font-mono text-muted-foreground bg-muted px-2 py-1 rounded">{tender.id}</span>
            <RiskBadge level={tender.riskLevel} />
            <span className="text-sm uppercase tracking-wider text-muted-foreground font-semibold">{tender.sector}</span>
          </div>
          <h1 className="text-3xl font-serif font-bold">{tender.title}</h1>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Building2 className="h-4 w-4" />
            <span>{tender.customer}</span>
            <span className="mx-2">•</span>
            <Target className="h-4 w-4" />
            <span>{tender.region}</span>
          </div>
        </div>
        
        <div className="flex flex-col items-end gap-2 bg-muted/30 p-4 rounded-xl border w-full md:w-auto shrink-0">
          <div className="text-sm text-muted-foreground uppercase font-semibold tracking-wider">Tender summasi</div>
          <div className="text-3xl font-bold font-mono text-primary">
            {new Intl.NumberFormat('uz-UZ').format(tender.amount)} {tender.currency}
          </div>
          <div className="text-sm text-muted-foreground mt-2">Muddat: {tender.deadline}</div>
        </div>
      </div>

      <WarningCard severity="warning" title={t("home.hero.trust_note")}>
        {t("intro.tender_detail")}
      </WarningCard>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover-elevate cursor-pointer">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Users className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <div className="text-2xl font-bold">{tender.applicants.length}</div>
              <div className="text-sm font-medium text-muted-foreground">Talabgorlar</div>
            </div>
            <Button asChild variant="outline" className="w-full mt-2">
              <LocalizedLink href={`/tenders/${tender.id}/applicants`}>Ko'rish</LocalizedLink>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer border-risk-purple/30">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-risk-purple/10 flex items-center justify-center text-risk-purple">
              <BrainCircuit className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <div className="text-2xl font-bold text-risk-purple">{tender.riskScore}</div>
              <div className="text-sm font-medium text-muted-foreground">AI Risk Score</div>
            </div>
            <Button asChild variant="outline" className="w-full mt-2 border-risk-purple/30 text-risk-purple hover:bg-risk-purple/10 hover:text-risk-purple">
              <LocalizedLink href={`/tenders/${tender.id}/ai-summary`}>AI Xulosa</LocalizedLink>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer border-risk-blue/30">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-risk-blue/10 flex items-center justify-center text-risk-blue">
              <LineChart className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <div className="text-2xl font-bold text-risk-blue">Tahlil</div>
              <div className="text-sm font-medium text-muted-foreground">Narxlar farqi</div>
            </div>
            <Button asChild variant="outline" className="w-full mt-2 border-risk-blue/30 text-risk-blue hover:bg-risk-blue/10 hover:text-risk-blue">
              <LocalizedLink href={`/tenders/${tender.id}/price-analysis`}>Solishtirish</LocalizedLink>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer border-risk-gray/30">
          <CardContent className="p-6 flex flex-col items-center justify-center text-center gap-3">
            <div className="w-12 h-12 rounded-full bg-risk-gray/10 flex items-center justify-center text-risk-gray">
              <FileText className="h-6 w-6" />
            </div>
            <div className="space-y-1">
              <div className="text-2xl font-bold text-risk-gray">
                {tender.applicants.reduce((acc, a) => acc + a.signals.length, 0)}
              </div>
              <div className="text-sm font-medium text-muted-foreground">Asoslovchi dalillar</div>
            </div>
            <Button asChild variant="outline" className="w-full mt-2 border-risk-gray/30 text-risk-gray hover:bg-risk-gray/10 hover:text-risk-gray">
              <LocalizedLink href={`/tenders/${tender.id}/evidence`}>Dalillarni ko'rish</LocalizedLink>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-8 pt-8">
        <div className="space-y-6">
          <h3 className="text-xl font-serif font-bold flex items-center justify-between">
            Asosiy talabgorlar ({tender.applicants.length})
            <Button asChild variant="link" size="sm" className="px-0">
              <LocalizedLink href={`/tenders/${tender.id}/applicants`}>Barchasini ko'rish <ArrowRight className="ml-1 w-4 h-4"/></LocalizedLink>
            </Button>
          </h3>
          <div className="space-y-4">
            {tender.applicants.slice(0, 3).map(app => (
              <Card key={app.id}>
                <CardContent className="p-4 flex flex-col sm:flex-row justify-between gap-4 items-start sm:items-center">
                  <div>
                    <div className="font-semibold">{app.name}</div>
                    <div className="text-sm text-muted-foreground font-mono mt-1">INN: {app.inn}</div>
                    <div className="text-sm font-medium mt-2">
                      Taklif: {new Intl.NumberFormat('uz-UZ').format(app.offerAmount)} UZS
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <RiskBadge level={app.riskLevel} />
                    <span className="text-xs font-semibold text-muted-foreground bg-muted px-2 py-1 rounded">Score: {app.riskScore}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-xl font-serif font-bold">Narx tahlili xulosasi</h3>
          <Card>
            <CardContent className="p-6 h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={priceData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} opacity={0.3} />
                  <XAxis type="number" tickFormatter={(val) => `${(val / 1000000000).toFixed(1)} mlrd`} fontSize={12} />
                  <YAxis dataKey="name" type="category" width={100} fontSize={12} />
                  <Tooltip formatter={(value: number) => new Intl.NumberFormat('uz-UZ').format(value) + ' UZS'} />
                  <Bar dataKey="price" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>

    </div>
  );
}
