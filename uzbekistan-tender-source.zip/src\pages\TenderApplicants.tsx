import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { MOCK_TENDERS } from "@/data/tenders";
import { DemoBadge } from "@/components/DemoBadge";
import { RiskBadge } from "@/components/RiskBadge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, ExternalLink } from "lucide-react";

export default function TenderApplicants() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language || "uz";
  const [, params] = useRoute("/:locale/tenders/:id/applicants");
  const tenderId = params?.id;

  const tender = MOCK_TENDERS.find(t => t.id === tenderId) || MOCK_TENDERS[0];

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <Button variant="ghost" asChild className="pl-0 hover:bg-transparent">
          <LocalizedLink href={`/tenders/${tender.id}`}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Tenderga qaytish
          </LocalizedLink>
        </Button>
        <DemoBadge />
      </div>

      <div>
        <h1 className="text-3xl font-serif font-bold mb-2">Talabgorlar tahlili</h1>
        <p className="text-muted-foreground">{t("intro.applicants")}</p>
      </div>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Tashkilot</TableHead>
              <TableHead className="text-right">Taklif narxi</TableHead>
              <TableHead className="text-center">Risk Status</TableHead>
              <TableHead className="text-right">AI Score</TableHead>
              <TableHead className="text-right">Amallar</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tender.applicants.map((app) => (
              <TableRow key={app.id}>
                <TableCell>
                  <div className="font-medium">{app.name}</div>
                  <div className="text-xs text-muted-foreground mt-1 font-mono">INN: {app.inn}</div>
                </TableCell>
                <TableCell className="text-right font-medium">
                  {new Intl.NumberFormat('uz-UZ').format(app.offerAmount)} {tender.currency}
                </TableCell>
                <TableCell className="text-center">
                  <RiskBadge level={app.riskLevel} />
                </TableCell>
                <TableCell className="text-right">
                  <span className={`text-lg font-bold ${
                    app.riskLevel === 'red' ? 'text-risk-red' : 
                    app.riskLevel === 'yellow' ? 'text-risk-yellow' : 'text-risk-green'
                  }`}>
                    {app.riskScore}
                  </span>
                </TableCell>
                <TableCell className="text-right">
                  <Button asChild size="sm" variant="outline">
                    <LocalizedLink href={`/organizations/${app.id}`}>
                      Pasport <ExternalLink className="ml-2 w-3 h-3"/>
                    </LocalizedLink>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
