import { AlertTriangle, CheckCircle, Info, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type Severity = "info" | "warning" | "danger" | "success";

interface WarningCardProps {
  severity: Severity;
  title?: string;
  children: React.ReactNode;
  className?: string;
  "data-testid"?: string;
}

export function WarningCard({ severity, title, children, className, "data-testid": testId }: WarningCardProps) {
  const config = {
    info: {
      icon: Info,
      colors: "bg-blue-50 text-blue-900 border-blue-200 dark:bg-blue-950/50 dark:text-blue-200 dark:border-blue-900",
      iconColor: "text-blue-500 dark:text-blue-400",
    },
    warning: {
      icon: AlertTriangle,
      colors: "bg-amber-50 text-amber-900 border-amber-200 dark:bg-amber-950/50 dark:text-amber-200 dark:border-amber-900",
      iconColor: "text-amber-500 dark:text-amber-400",
    },
    danger: {
      icon: XCircle,
      colors: "bg-red-50 text-red-900 border-red-200 dark:bg-red-950/50 dark:text-red-200 dark:border-red-900",
      iconColor: "text-red-500 dark:text-red-400",
    },
    success: {
      icon: CheckCircle,
      colors: "bg-green-50 text-green-900 border-green-200 dark:bg-green-950/50 dark:text-green-200 dark:border-green-900",
      iconColor: "text-green-500 dark:text-green-400",
    },
  };

  const { icon: Icon, colors, iconColor } = config[severity];

  return (
    <div className={cn("rounded-lg border p-4 flex gap-3", colors, className)} data-testid={testId}>
      <Icon className={cn("h-5 w-5 shrink-0 mt-0.5", iconColor)} />
      <div className="flex flex-col gap-1">
        {title && <h5 className="font-semibold leading-none tracking-tight">{title}</h5>}
        <div className="text-sm opacity-90 leading-relaxed">
          {children}
        </div>
      </div>
    </div>
  );
}
