import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { MOCK_ORGANIZATIONS } from "@/data/organizations";
import { DemoBadge } from "@/components/DemoBadge";
import { RiskBadge } from "@/components/RiskBadge";
import { WarningCard } from "@/components/WarningCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Building2, MapPin, User, Calendar, ShieldAlert } from "lucide-react";

export default function OrganizationPassport() {
  const { t, i18n } = useTranslation();
  const [, params] = useRoute("/:locale/organizations/:id");
  const orgId = params?.id;

  const org = MOCK_ORGANIZATIONS.find(o => o.id === orgId) || MOCK_ORGANIZATIONS[0];

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl space-y-8">
      <div className="flex items-center justify-between">
        <Button variant="ghost" asChild className="pl-0 hover:bg-transparent" onClick={() => window.history.back()}>
          <div><ArrowLeft className="mr-2 h-4 w-4" /> Orqaga</div>
        </Button>
        <DemoBadge />
      </div>

      <div className="flex flex-col md:flex-row justify-between items-start gap-6">
        <div>
          <h1 className="text-3xl font-serif font-bold mb-2">{org.name}</h1>
          <div className="flex items-center gap-3">
            <span className="text-sm font-mono bg-muted px-2 py-1 rounded">INN: {org.inn}</span>
            <span className={`text-sm px-2 py-1 rounded border font-medium ${org.status === 'active' ? 'bg-green-50 text-green-700 border-green-200' : ''}`}>
              Faol
            </span>
          </div>
        </div>
        
        <div className="flex flex-col items-center p-4 bg-muted/50 rounded-lg border min-w-[150px]">
          <span className="text-xs text-muted-foreground uppercase font-semibold mb-1">Risk Score</span>
          <span className={`text-4xl font-bold ${
            org.riskScore > 60 ? 'text-risk-red' : 
            org.riskScore > 30 ? 'text-risk-yellow' : 'text-risk-green'
          }`}>{org.riskScore}</span>
        </div>
      </div>

      <WarningCard severity="info">
        Tashkilot pasportidagi shaxsiy ma'lumotlar, ta'sischilar va yopiq ma'lumotlar jamoatchilik uchun niqoblangan.
      </WarningCard>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Asosiy ma'lumotlar</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3">
              <User className="w-5 h-5 text-muted-foreground shrink-0" />
              <div>
                <div className="text-sm text-muted-foreground">Rahbar</div>
                <div className="font-medium">{org.director}</div>
              </div>
            </div>
            <div className="flex gap-3">
              <Calendar className="w-5 h-5 text-muted-foreground shrink-0" />
              <div>
                <div className="text-sm text-muted-foreground">Ro'yxatdan o'tgan sana</div>
                <div className="font-medium">{org.founded}</div>
              </div>
            </div>
            <div className="flex gap-3">
              <MapPin className="w-5 h-5 text-muted-foreground shrink-0" />
              <div>
                <div className="text-sm text-muted-foreground">Yuridik manzil</div>
                <div className="font-medium">{org.address}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tender tarixi xulosasi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-muted/50 rounded-lg border text-center">
                <div className="text-2xl font-bold">{org.history.totalTenders}</div>
                <div className="text-xs text-muted-foreground uppercase">Qatnashgan</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg border text-center">
                <div className="text-2xl font-bold text-primary">{org.history.wonTenders}</div>
                <div className="text-xs text-muted-foreground uppercase">G'olib bo'lgan</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg border text-center">
                <div className="text-2xl font-bold text-risk-red">{org.history.cancelledContracts}</div>
                <div className="text-xs text-muted-foreground uppercase">Bekor qilingan</div>
              </div>
              <div className="p-3 bg-muted/50 rounded-lg border text-center">
                <div className="text-2xl font-bold text-risk-yellow">{org.history.delayedContracts}</div>
                <div className="text-xs text-muted-foreground uppercase">Kechikkan</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-risk-purple/20">
        <CardHeader className="bg-risk-purple/5 border-b">
          <CardTitle className="flex items-center gap-2 text-risk-purple">
            <ShieldAlert className="w-5 h-5" />
            AI Signallar va Topilmalar
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {org.signals.length > 0 ? (
            <div className="divide-y">
              {org.signals.map((sig, idx) => (
                <div key={idx} className="p-6 flex flex-col md:flex-row justify-between gap-4">
                  <div>
                    <div className="inline-block px-2 py-0.5 bg-muted rounded text-xs font-semibold uppercase mb-2">
                      {sig.type}
                    </div>
                    <div className="font-medium">{sig.description}</div>
                  </div>
                  <div className="text-sm text-muted-foreground text-right shrink-0">
                    Sana: {sig.date}<br/>
                    Manba: {sig.source}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-muted-foreground">
              Jiddiy risk signallari aniqlanmagan
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
