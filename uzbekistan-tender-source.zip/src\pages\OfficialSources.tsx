import { useTranslation } from "react-i18next";
import { DemoBadge } from "@/components/DemoBadge";
import { MOCK_SOURCES } from "@/data/sources";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Database, ShieldCheck, Link2 } from "lucide-react";

export default function OfficialSources() {
  const { t } = useTranslation();

  return (
    <div className="container mx-auto px-4 py-12 space-y-8 max-w-5xl">
      <div>
        <h1 className="text-3xl font-serif font-bold mb-4 flex items-center gap-3">
          {t("nav.official_sources")} <DemoBadge />
        </h1>
        <p className="text-muted-foreground">Tizim quyidagi davlat axborot tizimlari bilan integratsiya qilinadi.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {MOCK_SOURCES.map(source => (
          <Card key={source.id} className="relative overflow-hidden">
            {source.status === 'demo' && (
              <div className="absolute top-3 right-3">
                <Badge variant="outline" className="bg-risk-blue/10 text-risk-blue border-risk-blue/20">Demo connector</Badge>
              </div>
            )}
            {source.status === 'snapshot' && (
              <div className="absolute top-3 right-3">
                <Badge variant="outline" className="bg-risk-green/10 text-risk-green border-risk-green/20">Snapshot mavjud</Badge>
              </div>
            )}
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-primary" />
                {source.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{source.description}</p>
              
              <div className="flex items-center justify-between text-sm pt-4 border-t">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Link2 className="w-4 h-4" /> Ulanish holati:
                </div>
                <div className="font-medium">
                  {source.status === 'active' ? (
                    <span className="text-risk-green flex items-center gap-1"><ShieldCheck className="w-3 h-3"/> Faol</span>
                  ) : source.status === 'demo' ? (
                    <span className="text-risk-blue">Mock API</span>
                  ) : (
                    <span className="text-risk-yellow">Offline</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
