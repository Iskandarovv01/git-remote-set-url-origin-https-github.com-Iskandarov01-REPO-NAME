import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { ShieldAlert } from "lucide-react";
import { routes } from "@/shared/routes";

export function Footer() {
  const { t, i18n } = useTranslation();
  const locale = i18n.language || "uz";

  return (
    <footer className="border-t bg-muted/20 mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <Link href={`/${locale}`} className="flex items-center gap-2 mb-4">
              <ShieldAlert className="h-6 w-6 text-primary" />
              <span className="font-serif font-bold text-lg">Uzbekistan Tender</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-sm">
              {t("footer.disclaimer")}
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="font-serif font-semibold">{t("footer.col1")}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href={routes.home(locale)} className="hover:text-primary transition-colors">{t("nav.home")}</Link></li>
              <li><Link href={routes.tenders(locale)} className="hover:text-primary transition-colors">{t("nav.tenders")}</Link></li>
              <li><Link href={routes.publicDashboard(locale)} className="hover:text-primary transition-colors">{t("nav.public_dashboard")}</Link></li>
              <li><Link href={routes.reports(locale)} className="hover:text-primary transition-colors">{t("nav.reports")}</Link></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-serif font-semibold">{t("footer.col2")}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href={routes.aiEngine(locale)} className="hover:text-primary transition-colors">{t("nav.how_ai_works")}</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Risk scoring</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Evidence</Link></li>
              <li><Link href={routes.dataQuality(locale)} className="hover:text-primary transition-colors">{t("nav.data_quality")}</Link></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-serif font-semibold">{t("footer.col4")}</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href={routes.securityPrivacy(locale)} className="hover:text-primary transition-colors">{t("nav.security_privacy")}</Link></li>
              <li><Link href={routes.auditLog(locale)} className="hover:text-primary transition-colors">{t("nav.audit_log")}</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Demo data policy</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Public-safe summary</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} Uzbekistan Tender. Barcha huquqlar himoyalangan.</p>
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-risk-green"></span> Tizim ishlamoqda</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
