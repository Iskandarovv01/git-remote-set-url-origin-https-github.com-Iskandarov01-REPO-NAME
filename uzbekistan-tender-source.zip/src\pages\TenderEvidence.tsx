import { useTranslation } from "react-i18next";
import { useRoute } from "wouter";
import { LocalizedLink } from "@/components/LocalizedLink";
import { MOCK_TENDERS } from "@/data/tenders";
import { DemoBadge } from "@/components/DemoBadge";
import { RiskBadge } from "@/components/RiskBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, ShieldCheck, Database, Calendar } from "lucide-react";

export default function TenderEvidence() {
  const { t, i18n } = useTranslation();
  const [, params] = useRoute("/:locale/tenders/:id/evidence");
  const tenderId = params?.id;

  const tender = MOCK_TENDERS.find(t => t.id === tenderId) || MOCK_TENDERS[0];
  
  const allSignals = tender.applicants.flatMap(app => 
    app.signals.map(sig => ({
      ...sig,
      applicantName: app.name,
      source: "Soliq qo'mitasi ochiq ma'lumotlari (Demo)",
      date: "2025-02-20",
      confidence: "High",
      dataQuality: "snapshot_available"
    }))
  );

  return (
    <div className="container mx-auto px-4 py-8 space-y-8 max-w-5xl">
      <div className="flex items-center justify-between">
        <Button variant="ghost" asChild className="pl-0 hover:bg-transparent">
          <LocalizedLink href={`/tenders/${tender.id}`}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Tenderga qaytish
          </LocalizedLink>
        </Button>
        <DemoBadge />
      </div>

      <div>
        <h1 className="text-3xl font-serif font-bold mb-2">Tender bo'yicha dalillar</h1>
        <p className="text-muted-foreground">{t("intro.evidence")}</p>
      </div>

      <div className="space-y-4">
        {allSignals.length > 0 ? allSignals.map((sig, idx) => (
          <Card key={idx}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6 justify-between">
                <div className="space-y-3 flex-1">
                  <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-primary/10 text-primary uppercase">
                    {sig.type}
                  </div>
                  <h3 className="text-lg font-bold">{sig.description}</h3>
                  <div className="text-sm text-muted-foreground">
                    Tashkilot: <span className="font-medium text-foreground">{sig.applicantName}</span>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2 md:w-64 shrink-0 bg-muted/50 p-4 rounded-md border">
                  <div className="flex items-center gap-2 text-sm">
                    <Database className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium truncate" title={sig.source}>{sig.source}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span>{sig.date}</span>
                  </div>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t">
                    <span className="text-xs text-muted-foreground">Ishonchlilik:</span>
                    <span className="text-xs font-bold text-risk-green uppercase">{sig.confidence}</span>
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-xs text-muted-foreground">Data quality:</span>
                    <RiskBadge level="demo" showText={false} className="text-[10px] h-5" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )) : (
          <div className="text-center p-12 border rounded-md text-muted-foreground bg-card">
            {t("empty.evidence")}
          </div>
        )}
      </div>
    </div>
  );
}
