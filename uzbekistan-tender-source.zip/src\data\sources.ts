export const MOCK_SOURCES = [
  {
    id: "lex",
    name: "Lex.uz",
    description: "O'zbekiston Respublikasi Qonun hujjatlari ma'lumotlari milliy bazasi",
    status: "snapshot",
    lastSync: "2025-02-28 09:00:00",
    completeness: 98,
    type: "public"
  },
  {
    id: "dxarid",
    name: "Davlat xaridlari portali",
    description: "O'zbekiston Respublikasi davlat xaridlari elektron tizimi",
    status: "active",
    lastSync: "2025-02-28 14:30:00",
    completeness: 100,
    type: "public"
  },
  {
    id: "data_egov",
    name: "Data.egov.uz",
    description: "Ochiq ma'lumotlar portali",
    status: "active",
    lastSync: "2025-02-28 10:15:00",
    completeness: 95,
    type: "public"
  },
  {
    id: "soliq",
    name: "Soliq.uz",
    description: "Davlat soliq qo'mitasi ma'lumotlar bazasi",
    status: "demo",
    lastSync: "2025-02-28 12:00:00",
    completeness: 100,
    type: "private"
  },
  {
    id: "mehnat",
    name: "My.mehnat.uz",
    description: "Yagona milliy mehnat tizimi",
    status: "demo",
    lastSync: "2025-02-27 18:45:00",
    completeness: 100,
    type: "private"
  }
];
